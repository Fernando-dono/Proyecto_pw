package com.helados.caseros.tati.helados.caseros.tati.controller;

import com.helados.caseros.tati.helados.caseros.tati.entity.HeladoEntity;
import com.helados.caseros.tati.helados.caseros.tati.service.HeladoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/helados")
public class HeladosController {

    private final HeladoService heladoService;

    public HeladosController(HeladoService heladoService) {
        this.heladoService = heladoService;
    }

    @GetMapping
    public String listarHelados(Model model) {
        model.addAttribute("helados", heladoService.obtenerTodosLosHelados());
        return "helados/lista";
    }

    @GetMapping("/nuevo")
    public String mostrarFormularioCrear(Model model) {
        model.addAttribute("helado", new HeladoEntity());
        return "helados/formulario";
    }

    @PostMapping
    public String guardarHelado(@ModelAttribute("helado") HeladoEntity helado) {
        heladoService.guardarHelado(helado);
        return "redirect:/helados";
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model) {
        Optional<HeladoEntity> helado = heladoService.obtenerHeladoPorId(id);
        model.addAttribute("helado", helado);
        return "helados/formulario";
    }

    @PostMapping("/actualizar/{id}")
    public String actualizarHelado(@PathVariable Long id, @ModelAttribute("helado") HeladoEntity heladoActualizado) {
        heladoService.actualizarHelado(id, heladoActualizado);
        return "redirect:/helados";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarHelado(@PathVariable Long id) {
        heladoService.eliminarHelado(id);
        return "redirect:/helados";
    }
}
