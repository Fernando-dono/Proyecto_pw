/*<![CDATA[*/
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        e.preventDefault();

        const username = document.getElementById('username');
        const password = document.getElementById('password');
        const errorMessages = document.querySelectorAll('.error-message');

        // Reset form state
        resetFormErrors(username, password, errorMessages);

        // Validate inputs
        const isValid = validateForm(username, password);

        if (isValid) {
            submitLoginForm(this);
        }
    });
});

function resetFormErrors(username, password, errorMessages) {
    errorMessages.forEach(msg => msg.textContent = '');
    username.classList.remove('error');
    password.classList.remove('error');
}

function validateForm(username, password) {
    let isValid = true;

    if (username.value.trim() === '') {
        showError(username, 'Por favor, ingresa tu usuario.');
        isValid = false;
    }

    if (password.value.trim() === '') {
        showError(password, 'Por favor, ingresa tu contraseña.');
        isValid = false;
    } else if (password.value.length < 6) {
        showError(password, 'La contraseña debe tener al menos 6 caracteres.');
        isValid = false;
    }

    return isValid;
}

function showError(inputElement, message) {
    inputElement.classList.add('error');
    inputElement.nextElementSibling.textContent = message;
}

function submitLoginForm(form) {
    // Create FormData object
    const formData = new FormData(form);

    // Add CSRF token if using Spring Security
    const csrfToken = document.querySelector('input[name="_csrf"]')?.value;
    if (csrfToken) {
        formData.append('_csrf', csrfToken);
    }

    // Send AJAX request
    fetch(form.action, {
        method: 'POST',
        body: formData,
        headers: {
            'Accept': 'application/json'
        }
    })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            if (data.success) {
                window.location.href = data.redirectUrl || '/';
            } else {
                showError(document.getElementById(data.field || 'username'), data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Ocurrió un error al iniciar sesión. Por favor intenta nuevamente.');
        });
}
/*]]>*/