package com.helados.caseros.tati.helados.caseros.tati.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Entity
@Table(name = "helados")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HeladoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(nullable = false)
    private String sabor;

    @NotNull
    @Column(nullable = false)
    private Integer cantidadDisponible;  // en unidades

    @NotNull
    @Column(nullable = false)
    private Double precio;  // en pesos colombianos o USD según definas

    private String descripcion;  // opcional

    public @NotNull Integer getCantidad() {
        return 0;
    }
}