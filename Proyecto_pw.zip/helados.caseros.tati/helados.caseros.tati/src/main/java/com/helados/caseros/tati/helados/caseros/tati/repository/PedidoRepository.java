package com.helados.caseros.tati.helados.caseros.tati.repository;

import com.helados.caseros.tati.helados.caseros.tati.entity.EstadoPedido;
import com.helados.caseros.tati.helados.caseros.tati.entity.PedidoEntity;
import com.helados.caseros.tati.helados.caseros.tati.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PedidoRepository extends JpaRepository<PedidoEntity, Long> {
    Optional<PedidoEntity> findByUsuarioAndEstado(UserEntity usuario, EstadoPedido estado);
}
