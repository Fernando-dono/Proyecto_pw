package com.helados.caseros.tati.helados.caseros.tati.repository;

import com.helados.caseros.tati.helados.caseros.tati.entity.PedidoEntity;
import com.helados.caseros.tati.helados.caseros.tati.entity.PedidoHeladoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PedidoHeladoRepository extends JpaRepository<PedidoHeladoEntity, Long> {

    List<PedidoHeladoEntity> findByPedido(PedidoEntity pedido);



}
