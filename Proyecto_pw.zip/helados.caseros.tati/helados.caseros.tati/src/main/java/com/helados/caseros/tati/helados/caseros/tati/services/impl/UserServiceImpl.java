package com.helados.caseros.tati.helados.caseros.tati.services.impl;

import com.helados.caseros.tati.helados.caseros.tati.dto.UserRegistroDTO;
import com.helados.caseros.tati.helados.caseros.tati.entity.UserEntity;
import com.helados.caseros.tati.helados.caseros.tati.repository.UsuarioRepositorio;
import com.helados.caseros.tati.helados.caseros.tati.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UsuarioRepositorio usuarioRepositorio;

    @Override
    public void guardarUsuario(UserEntity usuario) {
        usuarioRepositorio.save(usuario);
    }

    @Override
    public boolean existePorEmail(String email) {
        return usuarioRepositorio.existsByEmail(email);
    }

    @Override
    public UserEntity obtenerPorEmail(String email) {
        return usuarioRepositorio.findByEmail(email).orElse(null);
    }

    @Override
    public void registrarUsuario(UserRegistroDTO userDto) {

    }
}