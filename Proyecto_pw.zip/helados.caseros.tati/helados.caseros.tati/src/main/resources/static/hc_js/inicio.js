th:inline="javascript"
  /*<![CDATA[*/
  document.querySelector('[th\\:attr="data-ubicacion"]').addEventListener('click', function() {
  if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(function(position) {
  const lat = position.coords.latitude;
  const lon = position.coords.longitude;

  // Abrir Google Maps con la ubicación
  window.open('https://www.google.com/maps?q=' + lat + ',' + lon, '_blank');
}, function() {
  alert('No se pudo obtener la ubicación.');
});
} else {
  alert('La geolocalización no es compatible con este navegador.');
}
});
  /*]]>*/

