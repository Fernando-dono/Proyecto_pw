package com.helados.caseros.tati.helados.caseros.tati.service;

import com.helados.caseros.tati.helados.caseros.tati.dto.UserRegistroDTO;
import com.helados.caseros.tati.helados.caseros.tati.entity.UserEntity;
import jakarta.validation.Valid;

public interface UserService {
    void guardarUsuario(UserEntity usuario);
    boolean existePorEmail(String email);
    UserEntity obtenerPorEmail(String email);

    void registrarUsuario(@Valid UserRegistroDTO userDto);
}

