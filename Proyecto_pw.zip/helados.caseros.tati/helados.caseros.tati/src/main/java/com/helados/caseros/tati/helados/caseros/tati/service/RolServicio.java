package com.helados.caseros.tati.helados.caseros.tati.service;

import com.helados.caseros.tati.helados.caseros.tati.entity.RolEntity;

import java.util.Optional;

public interface RolServicio {
    Optional<RolEntity> buscarPorNombre(String nombre);
}