package com.helados.caseros.tati.helados.caseros.tati.entity;

public enum EstadoPedido {
    EN_CARRITO,
    CONFIRMADO,
    CANCELADO,
    ENTREGADO
}