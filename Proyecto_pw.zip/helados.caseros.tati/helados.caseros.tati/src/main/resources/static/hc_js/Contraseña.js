document.getElementById('password').addEventListener('input', function() {
    const password = this.value.trim();
    const errorMessage = document.querySelector('.error-message');
    const loginBtn = document.querySelector('.login-btn');

    if (password.length >= 6) {
        errorMessage.textContent = '';
        this.classList.remove('error');
        loginBtn.disabled = false;
    } else {
        errorMessage.textContent = 'La contraseña debe tener al menos 6 caracteres.';
        this.classList.add('error');
        loginBtn.disabled = true;
    }
});

document.getElementById('passwordForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Inicio de sesión exitoso.');
});

document.querySelector('.back-arrow').addEventListener('click', function() {
    window.history.back();
});