package com.helados.caseros.tati.helados.caseros.tati.services.impl;

import com.helados.caseros.tati.helados.caseros.tati.entity.RolEntity;
import com.helados.caseros.tati.helados.caseros.tati.repository.RolRepository;
import com.helados.caseros.tati.helados.caseros.tati.service.RolServicio;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class RolServiceImpl implements RolServicio {

    private final RolRepository rolRepository;

    @Override
    public Optional<RolEntity> buscarPorNombre(String nombre) {
        return rolRepository.findByNombre(nombre);
    }
}
