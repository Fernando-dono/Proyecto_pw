package com.helados.caseros.tati.helados.caseros.tati.services.impl;

import com.helados.caseros.tati.helados.caseros.tati.entity.HeladoEntity;
import com.helados.caseros.tati.helados.caseros.tati.repository.HeladoRepository;
import com.helados.caseros.tati.helados.caseros.tati.service.HeladoService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HeladoServiceImpl implements HeladoService {

    private final HeladoRepository heladoRepository;

    public HeladoServiceImpl(HeladoRepository heladoRepository) {
        this.heladoRepository = heladoRepository;
    }

    @Override
    public List<HeladoEntity> obtenerTodosLosHelados() {
        return heladoRepository.findAll();
    }

    @Override
    public Optional<HeladoEntity> obtenerHeladoPorId(Long id) {
        return Optional.ofNullable(heladoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Helado no encontrado con ID: " + id)));
    }

    @Override
    public void guardarHelado(HeladoEntity helado) {
        heladoRepository.save(helado);
    }

    @Override
    public HeladoEntity actualizarHelado(Long id, HeladoEntity datosNuevos) {
        return obtenerHeladoPorId(id)
                .map(helado -> {
                    helado.setSabor(datosNuevos.getSabor());
                    helado.setCantidadDisponible(datosNuevos.getCantidadDisponible());
                    helado.setPrecio(datosNuevos.getPrecio());
                    // Agrega más campos si los tienes
                    return heladoRepository.save(helado);
                })
                .orElseThrow(() -> new RuntimeException("Helado con ID " + id + " no encontrado."));
    }

    @Override
    public void eliminarHelado(Long id) {
        heladoRepository.deleteById(id);
    }
}