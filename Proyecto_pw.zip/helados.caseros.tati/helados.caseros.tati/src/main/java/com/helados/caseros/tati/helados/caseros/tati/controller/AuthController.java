package com.helados.caseros.tati.helados.caseros.tati.controller;

import com.helados.caseros.tati.helados.caseros.tati.dto.UserRegistroDTO;
import com.helados.caseros.tati.helados.caseros.tati.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;

    @GetMapping("/registro")
    public String mostrarFormularioRegistro(Model model) {
        model.addAttribute("usuario", new UserRegistroDTO());
        return "registro"; // archivo registro.html en templates
    }

    @PostMapping("/registro")
    public String procesarFormularioRegistro(@ModelAttribute("usuario") @Valid UserRegistroDTO userDto,
                                             BindingResult result,
                                             Model model) {
        if (userService.existePorEmail(userDto.getEmail())) {
            result.rejectValue("email", null, "Ya existe una cuenta con ese email");
        }

        if (result.hasErrors()) {
            return "registro";
        }

        userService.registrarUsuario(userDto);
        return "redirect:/login?registryExitoso";
    }

    @GetMapping("/login")
    public String mostrarLogin() {
        return "login"; // archivo login.html en templates
    }
}