package com.helados.caseros.tati.helados.caseros.tati.services.impl;

import com.helados.caseros.tati.helados.caseros.tati.entity.*;
import com.helados.caseros.tati.helados.caseros.tati.repository.HeladoRepository;
import com.helados.caseros.tati.helados.caseros.tati.repository.PedidoHeladoRepository;
import com.helados.caseros.tati.helados.caseros.tati.repository.PedidoRepository;
import com.helados.caseros.tati.helados.caseros.tati.service.PedidoService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PedidoServiceImpl implements PedidoService {

    private final PedidoRepository pedidoRepository;
    private final PedidoHeladoRepository pedidoHeladoRepository;
    private final HeladoRepository heladoRepository;

    @Override
    public PedidoEntity obtenerCarritoDeUsuario(UserEntity usuario) {
        return pedidoRepository.findByUsuarioAndEstado(usuario, EstadoPedido.EN_CARRITO)
                .orElseGet(() -> {
                    PedidoEntity nuevoPedido = PedidoEntity.builder()
                            .usuario(usuario)
                            .estado(EstadoPedido.EN_CARRITO)
                            .fechaHora(LocalDateTime.now())
                            .total(0.0)
                            .build();
                    return pedidoRepository.save(nuevoPedido);
                });
    }


    @Override
    public PedidoEntity agregarHeladoAlCarrito(UserEntity usuario, Long heladoId, int cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor que 0.");
        }
        PedidoEntity carrito = obtenerCarritoDeUsuario(usuario);
        HeladoEntity helado = heladoRepository.findById(heladoId)
                .orElseThrow(() -> new RuntimeException("Helado no encontrado"));

        PedidoHeladoEntity item = PedidoHeladoEntity.builder()
                .pedido(carrito)
                .helado(helado)
                .cantidad(cantidad)
                .build();

        pedidoHeladoRepository.save(item);

        // Recalcular total del carrito
        double total = pedidoHeladoRepository.findByPedido(carrito).stream()
                .mapToDouble(ph -> ph.getHelado().getPrecio() * ph.getCantidad())
                .sum();

        carrito.setTotal(total);
        return pedidoRepository.save(carrito);
    }

    @Override
    public PedidoEntity confirmarPedido(Long pedidoId) {
        PedidoEntity pedido = pedidoRepository.findById(pedidoId)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        pedido.setEstado(EstadoPedido.CONFIRMADO);
        return pedidoRepository.save(pedido);
    }
}
