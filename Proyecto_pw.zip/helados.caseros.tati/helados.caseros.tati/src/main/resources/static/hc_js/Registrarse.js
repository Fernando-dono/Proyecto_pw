document.getElementById('email').addEventListener('input', function() {
    const email = this.value.trim();
    const emailRegex = /^[a-z0-9]+@[a-z0-9]+\.[a-z]{2,}$/;
    const errorMessage = document.querySelector('.error-message');
    const continueBtn = document.getElementById('continueBtn');

    if (email === '') {
        errorMessage.textContent = 'Digite tu correo electrónico.';
        this.classList.add('error');
        continueBtn.disabled = true;
        continueBtn.classList.remove('active');
    } else if (emailRegex.test(email)) {
        errorMessage.textContent = '';
        this.classList.remove('error');
        continueBtn.disabled = false;
        continueBtn.classList.add('active');
    } else {
        errorMessage.textContent = 'Correo inválido. Usa solo minúsculas y un dominio válido.';
        this.classList.add('error');
        continueBtn.disabled = true;
        continueBtn.classList.remove('active');
    }
});

// Redirige a la página de contraseña si el botón está habilitado
document.getElementById('continueBtn').addEventListener('click', function() {
    const email = document.getElementById('email').value.trim();
    const errorMessage = document.querySelector('.error-message');

    if (email === '') {
        errorMessage.textContent = 'Digite tu correo electrónico.';
        document.getElementById('email').classList.add('error');
    } else if (!this.disabled) {
        window.location.href = 'Contra.html';
    }
});