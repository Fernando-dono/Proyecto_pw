package com.helados.caseros.tati.helados.caseros.tati.service;

import com.helados.caseros.tati.helados.caseros.tati.entity.HeladoEntity;

import java.util.List;
import java.util.Optional;

public interface HeladoService {
    List<HeladoEntity> obtenerTodosLosHelados();
    Optional<HeladoEntity> obtenerHeladoPorId(Long id);
    void guardarHelado(HeladoEntity helado);
    void eliminarHelado(Long id);
    HeladoEntity actualizarHelado(Long id, HeladoEntity datosNuevos);
}