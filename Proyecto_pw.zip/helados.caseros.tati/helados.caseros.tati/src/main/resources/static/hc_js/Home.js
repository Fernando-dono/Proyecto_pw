document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const username = document.getElementById('username');
    const password = document.getElementById('password');
    const errorMessages = document.querySelectorAll('.error-message');

    // Limpiar errores anteriores
    errorMessages.forEach(msg => msg.textContent = '');
    username.classList.remove('error');
    password.classList.remove('error');

    let valid = true;

    if (username.value.trim() === '') {
        username.classList.add('error');
        username.nextElementSibling.textContent = 'Por favor, ingresa tu usuario.';
        valid = false;
    }

    if (password.value.trim() === '') {
        password.classList.add('error');
        password.nextElementSibling.textContent = 'Por favor, ingresa tu contraseña.';
        valid = false;
    }

    if (valid) {
        alert('Inicio de sesión exitoso');
    }
});