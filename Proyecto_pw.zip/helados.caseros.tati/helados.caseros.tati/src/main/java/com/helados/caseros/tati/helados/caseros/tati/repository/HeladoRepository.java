package com.helados.caseros.tati.helados.caseros.tati.repository;

import com.helados.caseros.tati.helados.caseros.tati.entity.HeladoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HeladoRepository extends JpaRepository<HeladoEntity, Long> {
}
