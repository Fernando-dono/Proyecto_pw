package com.helados.caseros.tati.helados.caseros.tati.controller;

import com.helados.caseros.tati.helados.caseros.tati.service.PedidoService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/pedidos")
@RequiredArgsConstructor
public class PedidoController {

    private final PedidoService pedidoService;

    @PostMapping("/confirmar")
    public ResponseEntity<String> confirmarPedido(@AuthenticationPrincipal UserDetails userDetails) {
        pedidoService.confirmarPedido(Long.valueOf(userDetails.getUsername()));
        return ResponseEntity.ok("Pedido confirmado con éxito");
    }
}
