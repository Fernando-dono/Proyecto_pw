package com.helados.caseros.tati.helados.caseros.tati.service;

import com.helados.caseros.tati.helados.caseros.tati.entity.PedidoEntity;
import com.helados.caseros.tati.helados.caseros.tati.entity.UserEntity;

import java.util.List;
import java.util.Optional;

public interface PedidoService {
    PedidoEntity obtenerCarritoDeUsuario(UserEntity usuario);
    PedidoEntity agregarHeladoAlCarrito(UserEntity usuario, Long heladoId, int cantidad);
    PedidoEntity confirmarPedido(Long pedidoId);
}