package com.helados.caseros.tati.helados.caseros.tati.entity;

import jakarta.persistence.*;
import lombok.*;

@Builder
@Entity
@Table(name = "pedido_helados")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PedidoHeladoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "pedido_id", nullable = false)
    private PedidoEntity pedido;

    @ManyToOne
    @JoinColumn(name = "helado_id", nullable = false)
    private HeladoEntity helado;

    private int cantidad;

    private double precioUnitario;


}
